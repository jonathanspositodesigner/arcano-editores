"""Footage file-format table: extension -> AE source-format code and defaults.

Derived empirically by importing `samples/assets/` in AE 2026 and decoding the
resulting `sspc` chunks (see the `filesource-aep-format` notes). `source_format`
is the 4-char code stored in `SspcChunk.source_format_type`.
"""

from __future__ import annotations

from typing import NamedTuple

from ..enums import ImportAsType


class FileFormat(NamedTuple):
    """Static per-format defaults for footage import."""

    source_format: str
    """4-char `sspc.source_format_type` code (e.g. `png!`, `oEXR`)."""

    alpha_premultiplied: bool
    """When the footage has alpha, `True` selects PREMULTIPLIED, else STRAIGHT."""

    opti: str
    """`opti` asset-info strategy, verified against AE 2026:

    - `"empty"`: AE re-reads the located file (FBX); an empty `opti` works.
    - `"exr"`: AE needs the `oEXR` header (see `build_exr_opti_data`) to
      place an EXR's data window.
    - `"generic"`: AE's generic media importer needs the 58-byte `opti` header
      (PNG, JPEG, TGA, MOV, WAV, HEIC). AE opens a PNG still with an empty
      `opti` but crashes as soon as it renders it.
    - `"tiff"`: AE needs the 602-byte TIFF-specific header (see
      `build_tiff_opti_data`).
    - `"psd"`: the 602-byte Photoshop header AE writes for the merged
      document (see `build_psd_opti_data`).
    - `"text"`: the 596-byte Illustrator/PDF/EPS header (see
      `build_ai_document_opti_data` and `build_text_opti_data`).
    - `"dpx"`: AE needs the 48-byte DPX/Cineon format-options header (see
      `build_dpx_opti_data`).
    - `"unsupported"`: AE requires a format-specific `opti` not yet
      reverse-engineered; import is refused rather than crashing AE."""

    sequence: bool = True
    """`False` for formats AE 2026 refuses to import as an image sequence
    ("files of type ... cannot be used as sequences"): movies, audio, HEIC,
    3D scenes and data files."""

    media_flag: bool = False
    """`True` for the formats whose footage AE 2026's import marks in `sspc`
    (`SspcChunk.media_format`, and `media_file` for a single file): JPEG,
    BMP/GIF, HEIC, movies, audio and data files."""


#: `sspc.source_format_type` of a 3D model scene (`.fbx`).
FORMAT_3D_MODEL_SCENE = "LDOM"

#: BMP/GIF have no dedicated importer; AE tags them with the platform's
#: generic still importer: AE 2026 macOS writes IMIO, Windows STIL, for
#: stills and sequences alike (imio_*.aep vs media_replacement.aep
#: fixtures, plus a Windows import of bmp.bmp/gif.gif). An IMIO still opens
#: on either platform, but an IMIO sequence never opens on Windows and a
#: STIL sequence never opens on macOS.
GENERIC_STILL_FORMATS = {"macos": "IMIO", "windows": "STIL"}


def platform_source_format(fmt: FileFormat, *, windows: bool) -> str:
    """The `sspc` code AE on the target platform writes for `fmt`.

    Args:
        fmt: The file's format (a still or a sequence frame).
        windows: `True` to tag the source for AE on Windows (see
            `GENERIC_STILL_FORMATS`).
    """
    if windows and fmt.source_format == GENERIC_STILL_FORMATS["macos"]:
        return GENERIC_STILL_FORMATS["windows"]
    return fmt.source_format


_FILE_FORMATS: dict[str, FileFormat] = {
    ".exr": FileFormat("oEXR", True, "exr"),
    ".mov": FileFormat("MOoV", False, "generic", sequence=False, media_flag=True),
    ".m4v": FileFormat("MOoV", False, "generic", sequence=False, media_flag=True),
    # AE 2026 imports .mp4 through its Media Core importer, which stamps
    # "XCEX" rather than the QuickTime family's "MOoV" (older AE releases
    # wrote "MPEG"/"MOoV" for the same files).
    ".mp4": FileFormat("XCEX", False, "generic", sequence=False, media_flag=True),
    ".aiff": FileFormat("AIFC", False, "generic", sequence=False, media_flag=True),
    # AIFF alias; verified: AE 2026 imports aif.aif as AIFC footage
    # (media_gap_formats.aep fixture).
    ".aif": FileFormat("AIFC", False, "generic", sequence=False, media_flag=True),
    ".wav": FileFormat("WAVE", False, "generic", sequence=False, media_flag=True),
    ".png": FileFormat("png!", False, "generic"),
    ".tif": FileFormat("TIF ", False, "tiff"),
    ".tiff": FileFormat("TIF ", False, "tiff"),
    # DPX and Cineon still frames and sequences; verified: AE 2026 imports
    # both as sDPX footage with a 48-byte format-options header
    # (media_gap_formats.aep fixture).
    ".dpx": FileFormat("sDPX", False, "dpx"),
    ".cin": FileFormat("sDPX", False, "dpx"),
    ".heic": FileFormat("AIDE", False, "generic", sequence=False, media_flag=True),
    ".heif": FileFormat("AIDE", False, "generic", sequence=False, media_flag=True),
    ".jpg": FileFormat("ZPEG", False, "generic", media_flag=True),
    ".jpeg": FileFormat("ZPEG", False, "generic", media_flag=True),
    ".tga": FileFormat("TPIC", False, "generic"),
    # Platform-specific generic still importer; see GENERIC_STILL_FORMATS.
    ".bmp": FileFormat(
        GENERIC_STILL_FORMATS["macos"], False, "generic", media_flag=True
    ),
    ".gif": FileFormat(
        GENERIC_STILL_FORMATS["macos"], False, "generic", media_flag=True
    ),
    ".psd": FileFormat("8BPS", False, "psd"),
    ".psb": FileFormat("8BPS", False, "psd"),
    # Video/audio containers (generic opti; codec bytes re-derived by AE).
    ".m4a": FileFormat("MOoV", False, "generic", sequence=False, media_flag=True),
    ".mp3": FileFormat("MP3A", False, "generic", sequence=False, media_flag=True),
    # AAC in an ADTS stream (audio only); source code confirmed against an
    # AE 2026 import of samples/assets/aac.aac.
    ".aac": FileFormat("MPEG", False, "generic", sequence=False, media_flag=True),
    ".swf": FileFormat("SWF ", False, "generic", sequence=False, media_flag=True),
    ".mpeg": FileFormat("MPEO", False, "generic", sequence=False, media_flag=True),
    ".mpg": FileFormat("MPEO", False, "generic", sequence=False, media_flag=True),
    # Motion-graphics data stream (duration from the sampled time range).
    ".mgjson": FileFormat("sjgm", False, "generic", sequence=False, media_flag=True),
    # 3D scene - empty opti; AE re-reads the scene and uses default render dims.
    ".fbx": FileFormat(FORMAT_3D_MODEL_SCENE, False, "empty", sequence=False),
    # Data footage - 0x0 items; a reversed code: "nosj" for json, and for
    # txt / csv the tab- / comma-separated-values importer's NUL-led
    # "\0vst" / "\0vsc" (AE 2026 import; it reads back as "" - the text
    # before the NUL).
    ".txt": FileFormat("\x00vst", False, "generic", sequence=False, media_flag=True),
    ".csv": FileFormat("\x00vsc", False, "generic", sequence=False, media_flag=True),
    ".json": FileFormat("nosj", False, "generic", sequence=False, media_flag=True),
    ".wmv": FileFormat("WMED", False, "generic", sequence=False, media_flag=True),
    # Radiance HDR - format-specific 30-byte opti.
    ".hdr": FileFormat("RHDR", False, "hdr"),
    # Canon CRW, developed by Camera Raw - format-specific 30-byte opti.
    ".crw": FileFormat("Craw", False, "craw"),
    # Vector / PostScript / PDF - shared 596-byte TEXT opti.
    ".ai": FileFormat("TEXT", False, "text"),
    ".eps": FileFormat("TEXT", False, "text"),
    ".pdf": FileFormat("TEXT", False, "text"),
}


# Formats AE imports as footage but py-aep does NOT support, with reasons:
#   .c4d  -> "C4DC" - AE accepts the generic opti (it rebuilds its own on
#            save), but the footage size, frame rate and duration come from the
#            scene's render settings and document timeline, which need a Cinema
#            4D scene parser
#   .nef  -> "Craw" - Camera Raw develops it at a per-camera crop the file
#            does not record (a Nikon D1's 2012x1324 sensor opens 2000x1312)
# AE refuses .avi (codec), .flv/.ps (invalid type) on import. .ma imports
# only as a cropped comp (not footage) - a separate comp-conversion feature.


# Which `ImportAsType` values `ImportOptions.can_import_as()` accepts per
# extension. Values for the asset extensions present in `samples/assets/` were
# measured empirically in AE 2026 via `scripts/jsx/can_import_as_matrix.jsx`
# (the matrix lives at `scripts/jsx/can_import_as_matrix.json`). Note the
# non-obvious cases that the empirical run surfaced:
#   - FOOTAGE is NOT universal: `.svg` and `.aep` reject it.
#   - COMP and COMP_CROPPED_LAYERS differ: `.exr`/`.svg` allow the cropped
#     variant but not plain COMP.
#   - `.mov` accepts PROJECT (a QuickTime file may carry an AE project).
# Extensions not in `samples/assets/` (`.ai`, `.pdf`, `.aet`, `.jpeg`, `.tiff`)
# follow documented AE behavior / format aliases and are marked below.
_FOOTAGE = ImportAsType.FOOTAGE
_COMP = ImportAsType.COMP
_CROPPED = ImportAsType.COMP_CROPPED_LAYERS
_PROJECT = ImportAsType.PROJECT

_IMPORT_AS_TYPES: dict[str, frozenset[ImportAsType]] = {
    # Layered Photoshop - footage, comp, or comp-cropped.
    ".psd": frozenset({_FOOTAGE, _COMP, _CROPPED}),
    ".psb": frozenset({_FOOTAGE, _COMP, _CROPPED}),
    # Vector / PostScript / PDF - footage, comp, or comp-cropped (AE-measured).
    ".ai": frozenset({_FOOTAGE, _COMP, _CROPPED}),
    ".eps": frozenset({_FOOTAGE, _COMP, _CROPPED}),
    ".pdf": frozenset({_FOOTAGE, _COMP, _CROPPED}),
    # Multi-channel EXR - footage or comp-cropped, but not plain comp.
    ".exr": frozenset({_FOOTAGE, _CROPPED}),
    # SVG - comp-cropped only; cannot import as plain footage.
    ".svg": frozenset({_CROPPED}),
    # Still images - footage only.
    ".png": frozenset({_FOOTAGE}),
    ".jpg": frozenset({_FOOTAGE}),
    ".jpeg": frozenset({_FOOTAGE}),  # alias of .jpg
    ".tif": frozenset({_FOOTAGE}),
    ".tiff": frozenset({_FOOTAGE}),  # alias of .tif
    ".dpx": frozenset({_FOOTAGE}),
    ".cin": frozenset({_FOOTAGE}),
    ".heic": frozenset({_FOOTAGE}),
    ".heif": frozenset({_FOOTAGE}),
    ".tga": frozenset({_FOOTAGE}),
    ".bmp": frozenset({_FOOTAGE}),
    ".gif": frozenset({_FOOTAGE}),
    ".hdr": frozenset({_FOOTAGE}),
    ".crw": frozenset({_FOOTAGE}),
    # Video - footage or project.
    ".mov": frozenset({_FOOTAGE, _PROJECT}),
    ".m4v": frozenset({_FOOTAGE}),
    ".mp4": frozenset({_FOOTAGE}),
    ".wmv": frozenset({_FOOTAGE}),
    # Audio - footage only (m4a may also carry an AE project).
    ".aiff": frozenset({_FOOTAGE}),
    ".aif": frozenset({_FOOTAGE}),
    ".wav": frozenset({_FOOTAGE}),
    ".m4a": frozenset({_FOOTAGE, _PROJECT}),
    # AE still reports these importable as footage.
    ".fbx": frozenset({_FOOTAGE}),
    ".txt": frozenset({_FOOTAGE}),
    ".csv": frozenset({_FOOTAGE}),
    ".json": frozenset({_FOOTAGE}),
    ".mgjson": frozenset({_FOOTAGE}),
    ".mp3": frozenset({_FOOTAGE}),
    ".aac": frozenset({_FOOTAGE}),
    ".swf": frozenset({_FOOTAGE}),
    ".mpeg": frozenset({_FOOTAGE}),
    ".mpg": frozenset({_FOOTAGE}),
    # Project / template - project only (.aet not in samples/assets).
    ".aep": frozenset({_PROJECT}),
    ".aet": frozenset({_PROJECT}),
}


# Extensions imported by converting the file directly into a composition
# (no FileSource/footage item), so they are absent from `_FILE_FORMATS` yet
# are still importable. `can_import_as` gates these on `_IMPORT_AS_TYPES`
# alone (no media-format lookup).
COMP_CONVERSION_EXTENSIONS: frozenset[str] = frozenset({".svg"})

# Layered formats AE imports as a composition of per-layer footage. Illustrator
# /PDF layers are PDF Optional Content Groups (see resolvers.ai_layers);
# Photoshop layers come from the file's layer records (see resolvers.psd_layers).
AI_COMP_EXTENSIONS: frozenset[str] = frozenset({".ai", ".pdf"})
PSD_COMP_EXTENSIONS: frozenset[str] = frozenset({".psd", ".psb"})
# EPS is single-stream PostScript with no layer structure, so AE rasterizes it
# to a one-layer composition (verified: AE 2026 imports eps.eps as a 1-layer
# comp). Handled separately from AI_COMP_EXTENSIONS, which needs PDF OCGs.
EPS_COMP_EXTENSIONS: frozenset[str] = frozenset({".eps"})


def get_import_as_types(suffix: str) -> frozenset[ImportAsType]:
    """Return the `ImportAsType` values valid for a file extension.

    Args:
        suffix: The file extension including the leading dot (e.g. `.psd`).

    Returns:
        The set of accepted import types, or an empty set for an extension
        with no recorded import support.
    """
    return _IMPORT_AS_TYPES.get(suffix.lower(), frozenset())


def get_file_format(suffix: str) -> FileFormat:
    """Return the `FileFormat` for a file extension (e.g. `.png`).

    Args:
        suffix: The file extension including the leading dot.

    Raises:
        ValueError: If the extension is not a supported footage format.
    """
    fmt = _FILE_FORMATS.get(suffix.lower())
    if fmt is None:
        raise ValueError(f"Unsupported footage format: {suffix!r}")
    return fmt
