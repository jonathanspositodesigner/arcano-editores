from __future__ import annotations

from typing import TYPE_CHECKING, List, cast

from ...binary.bin_utils import to_dividend_divisor
from ...binary.utils import (
    ChunkNotFoundError,
    find_by_type,
    find_chunks_after,
    toggle_flag_chunk,
)
from ...color.envelope import (
    PROFILE_TYPE_OCIO,
    build_icc_envelope,
    parse_envelope,
)
from ...color.icc import default_icc_library
from ...color.ocio import ocio_color_profile_envelope, require_ocio_config
from ...enums import (
    AlphaMode,
    FieldSeparationType,
    LinearLightMode,
    PulldownPhase,
)
from ...enums.mappings import map_media_color_space, profile_id_for_name
from ..descriptors import ChunkField
from ..validators import (
    _validate_number,
    validate_bool,
    validate_conform_frame_rate,
    validate_rgb_color,
    validate_string,
)

if TYPE_CHECKING:
    from ...binary.chunk import ListChunk
    from ...binary.footage_chunks import SspcChunk
    from ...binary.scalar_chunks import U1Chunk, Utf8Chunk
    from ...color.envelope import ColorProfile
    from ...color.icc import IccProfileLibrary
    from ..project import Project


#: `apid` value meaning "no profile assigned" (the media's own profile wins).
_UNASSIGNED_PROFILE = b"\xff" * 16

#: `LIST:CLRS` records and the first file version (format, minor) that has
#: them; each is a marker chunk and the `Utf8` that follows it. AE 2025
#: (96.9) added `hdrm` - AE 2022-2024 drop it when they save a file that has
#: it (clrs_ae20XX.aep fixtures) - and `Mcsp`/`ocsp` arrived with 93.40
#: (samples/versions: absent from the AE 2018 project, present from AE 2022).
_CLRS_RECORDS_SINCE = (("hdrm", (96, 9)), ("Mcsp", (93, 40)), ("ocsp", (93, 40)))


def _validate_has_alpha(value: object, instance: object | None = None) -> None:
    """Reject an alpha interpretation for footage that has no alpha channel.

    The `sspc` alpha byte doubles as the "no alpha channel" marker (3), so
    writing a mode over it would claim an alpha channel the media does not
    have. AE greys the whole alpha section out for such footage.
    """
    if instance is not None and not instance.has_alpha:  # type: ignore[attr-defined]
        raise ValueError(
            "cannot set alpha_mode: the footage has no alpha channel "
            "(has_alpha is False)"
        )


#: The smallest non-zero conform rate After Effects can open a project with.
_MIN_CONFORM_FRAME_RATE = 0.0005


def _retime_sequence(sspc: SspcChunk, rate: float) -> None:
    """Move an image sequence to `rate`, keeping its frame count.

    A sequence's stored duration is its frame count over its rate. AE takes
    the rate to the nearest thousandth (29.97, not the 16.16 slot's
    29.9700012) and leaves the fraction unreduced: 12 frames is 12/24 at
    24 fps, 1200/2997 at 29.97 (measured on AE 2026).
    """
    frames = round(sspc.duration * sspc.native_frame_rate)
    sspc.native_frame_rate = rate
    _store_frames_over_rate(sspc, frames, round(rate, 3))


def _store_frames_over_rate(sspc: SspcChunk, frames: int, rate: float) -> None:
    """Store a sequence's duration as AE does: `frames` over `rate`, the
    fraction unreduced (3/30, not 1/10, in every AE-authored sequence)."""
    rate_num, rate_den = to_dividend_divisor(rate)
    if frames * rate_den <= 0xFFFFFFFF:
        sspc.duration_dividend = frames * rate_den
        sspc.duration_divisor = rate_num
    else:
        # Too many frames for the unreduced form in the u4 dividend (a huge
        # frame range at a fractional rate): store it reduced.
        sspc.duration = frames / rate


class FootageSource:
    """
    The `FootageSource` object holds information describing the source of some
    footage. It is used as the `main_source` of a `FootageItem` object, or the
    `proxy_source` of a `CompItem` object or `FootageItem`.

    See: https://ae-scripting.docsforadobe.dev/sources/footagesource/
    """

    _owns_name: bool = False
    """Whether the item display name lives in this source's own `opti` chunk.

    AE keeps a solid's and a placeholder's name there and leaves the
    item-level `Utf8` chunk empty; file footage is named through that `Utf8`
    chunk instead.
    """

    alpha_mode = ChunkField.enum(
        AlphaMode,
        "_sspc",
        "alpha_mode_raw",
        validate=_validate_has_alpha,
        post_set="_on_alpha_mode_set",
    )
    """Defines how the alpha information in the footage is interpreted.
    If `has_alpha` is `False`, this attribute has no relevant meaning.
    Read / Write."""

    field_separation_type = ChunkField.enum(
        FieldSeparationType,
        "_sspc",
        "field_separation_type",
    )
    """How the fields are to be separated in non-still footage.
    Read / Write."""

    has_alpha = ChunkField[bool]("_sspc", "has_alpha", read_only=True)
    """When `True`, the footage has an alpha component. In this case, the
    attributes `alpha_mode`, `invert_alpha`, and `premultiplied` have valid
    values. When `False`, those attributes have no relevant meaning for the
    footage. Read-only."""

    high_quality_field_separation = ChunkField.bool(
        "_sspc", "high_quality_field_separation"
    )
    """When `True`, After Effects uses special algorithms to determine how to
    perform high-quality field separation. Read / Write."""

    invert_alpha = ChunkField.bool(
        "_sspc",
        "invert_alpha",
    )
    """When `True`, an alpha channel in a footage clip or proxy should be
    inverted. This attribute is valid only if an alpha is present. If
    `has_alpha` is `False`, or if `alpha_mode` is
    [AlphaMode.IGNORE][py_aep.enums.AlphaMode], this attribute is
    ignored. Read / Write."""

    loop = ChunkField[int](
        "_sspc",
        "loop",
        validate=_validate_number(min=1, max=9999, integer=True),
    )
    """The number of times that the footage is to be played consecutively
    when used in a composition. Read / Write."""

    premul_color = ChunkField[List[float]](
        "_sspc",
        "premul_color",
        validate=validate_rgb_color,
    )
    """The color to be premultiplied. This attribute is valid only if
    the `alpha_mode` is
    [AlphaMode.PREMULTIPLIED][py_aep.enums.AlphaMode].
    Read / Write."""

    interpret_as_linear_light = ChunkField.enum(
        LinearLightMode,
        "_linl",
        "value",
        default=LinearLightMode.OFF,
    )
    """The Interpret As Linear Light setting from the Interpret Footage >
    Color Management tab. Read / Write.

    Note:
        Not exposed in ExtendScript."""

    @property
    def conform_frame_rate(self) -> float:
        """A frame rate to use instead of the `native_frame_rate` value. If
        set to 0, the `native_frame_rate` is used instead. Read / Write.

        A sequence of stills has no rate of its own, so its assumed rate is
        kept as the native rate and reads back here; setting one rescales
        the duration over the new rate, and `0` is ignored (a sequence
        always runs at some assumed rate). A placeholder keeps its rate the
        same way, but its duration stays in seconds. Matches After Effects.

        Note:
            Unlike ExtendScript, a proxy reports its own rate. ExtendScript
            reads a proxy's rate as assumed only when the item's main source
            is a sequence or a placeholder: a sequence or placeholder proxy
            of a movie or comp reads 0, even right after setting it, and an
            unconformed movie proxy of a sequence reads its native rate.

        Raises:
            ValueError: If the rate is outside 0-999 or between 0 and 0.0005
                (After Effects cannot open a project holding such a rate).
        """
        sspc = self._sspc
        if self._rate_is_assumed:
            return sspc.conform_frame_rate or sspc.native_frame_rate
        return sspc.conform_frame_rate

    @conform_frame_rate.setter
    def conform_frame_rate(self, value: float) -> None:
        validate_conform_frame_rate(value)
        if 0 < value < _MIN_CONFORM_FRAME_RATE:
            # AE 2026 takes the rate to the nearest thousandth: below 0.0005
            # that is 0, and AE refuses to open the project ("zero
            # denominator in ratio multiply"); 0.0005 opens, as a 3000 s
            # 3-frame sequence.
            raise ValueError(
                f"conform_frame_rate must be 0 or at least "
                f"{_MIN_CONFORM_FRAME_RATE}, got {value}"
            )
        sspc = self._sspc
        if not self._rate_is_assumed:
            sspc.conform_frame_rate = value
            return
        if not value:
            return
        # AE keeps an assumed rate in the native slot and the conform slot
        # at 0.
        sspc.conform_frame_rate = 0.0
        if self._is_sequence:
            _retime_sequence(sspc, value)
        else:
            sspc.native_frame_rate = value

    display_frame_rate = ChunkField[float](
        "_sspc",
        "display_frame_rate",
        read_only=True,
    )
    """The effective frame rate as displayed and rendered in compositions.
    If `remove_pulldown` is active, the rate is multiplied by 0.8.
    Read-only."""

    remove_pulldown = ChunkField.enum(
        PulldownPhase,
        "_sspc",
        "remove_pulldown",
        post_set="_on_remove_pulldown_set",
    )
    """Controls which pulldown phase to remove from the source footage.
    [PulldownPhase.OFF][py_aep.enums.PulldownPhase] by default.
    Read / Write."""

    def _on_alpha_mode_set(self) -> None:
        """Co-set the `sspc` premultiplied flag bit with the alpha mode.

        AE writes the mode byte and bit 0 of the alpha flags together:
        premultiplied (1) sets the bit, straight (0) clears it, and ignore
        (2) leaves it as it was (AE 2026, a PNG and an FBX alike). It
        rejects a premultiplied interpretation - resetting the footage to
        straight alpha when the file is opened - if the bit is clear.
        """
        mode = self.alpha_mode
        if mode != AlphaMode.IGNORE:
            self._sspc.premultiplied = mode == AlphaMode.PREMULTIPLIED

    def _on_remove_pulldown_set(self) -> None:
        """Co-set a field order when a 3:2 pulldown phase is applied.

        AE requires field separation to be set whenever a standard 3:2
        pulldown phase (binary 1-5) is removed; a file with such a phase but
        no field order is rejected ("field order must be set before 3:2
        pulldown can be removed"). The 24P-advance phases (binary 6-10) are
        exempt. Mirror AE's Interpret Footage dialog, which forces a field
        order and defaults to Upper Field First.
        """
        if (
            1 <= self._sspc.remove_pulldown <= 5
            and self.field_separation_type == FieldSeparationType.OFF
        ):
            self.field_separation_type = FieldSeparationType.UPPER_FIELD_FIRST

    native_frame_rate = ChunkField[float]("_sspc", "native_frame_rate", read_only=True)
    """The native frame rate of the footage. Read-only."""

    _width = ChunkField[int]("_sspc", "width", read_only=True)
    _height = ChunkField[int]("_sspc", "height", read_only=True)
    _pixel_aspect = ChunkField[float]("_sspc", "pixel_aspect", read_only=True)
    _footage_missing = ChunkField[bool](
        "_sspc",
        "footage_missing_at_save",
        read_only=True,
    )
    _start_frame = ChunkField[int]("_sspc", "start_frame", read_only=True)
    _end_frame = ChunkField[int]("_sspc", "end_frame", read_only=True)

    @property
    def _has_audio(self) -> bool:
        return self._sspc.audio_sample_rate > 0

    @property
    def _duration(self) -> float:
        """Total duration in seconds (with conform and loop)."""
        sspc = self._sspc
        conform = sspc.conform_frame_rate
        if conform == 0:
            return sspc.duration * sspc.loop
        # A conform plays the same frames at another rate, so AE's duration
        # is the frame count over that rate: exactly 48 / 24 = 2.0 s for a
        # 48-frame 23.976 movie. Rescaling the stored duration instead drifts
        # by the 16.16 error of the stored native rate (1.999998 s).
        frames = round(sspc.duration * sspc.native_frame_rate)
        return frames / conform * sspc.loop

    @property
    def _frame_duration(self) -> int:
        # Rounded, not truncated: a 48-frame 23.976 movie lasts 48 frames,
        # though its 16.16 stored rate puts the product at 47.99995.
        return round(self._duration * self.display_frame_rate)

    def __init__(
        self,
        *,
        _sspc: SspcChunk,
        _linl: U1Chunk | None = None,
        _clrs: ListChunk | None = None,
    ) -> None:
        self._sspc = _sspc
        self._linl = _linl
        self._clrs = _clrs
        self._project: Project | None = None

    @property
    def _is_sequence(self) -> bool:
        """Whether the source is an image sequence (a folder of frames).

        A sequence has no frame rate of its own, so AE keeps its "assume this
        frame rate" in the native-rate slot instead of the conform slot.
        """
        return False

    @property
    def _windows(self) -> bool:
        """Whether this source's project is for After Effects on Windows
        (see `py_aep.parse`'s `platform`)."""
        return self._project is not None and self._project._windows

    _rate_from_media: bool = False
    """Whether a newly built image sequence takes its rate from its first
    frame (an animated GIF). A replace then keeps that rate: neither a
    placeholder's or sequence's assumed rate nor a movie's conform carries
    over (AE 2026)."""

    @property
    def _rate_is_assumed(self) -> bool:
        """Whether the native-rate slot holds a rate the user chose rather
        than one measured from media: a sequence's "assume this frame rate",
        or the rate a placeholder was created with."""
        return self._is_sequence

    def _carry_interpretation_to(self, new: FootageSource) -> None:
        """Copy the Interpret Footage settings AE carries over to `new`.

        AE keeps what the user chose in the Interpret Footage dialog when a
        source is replaced, and takes everything it measures from the new
        file: the dimensions, duration, native frame rate, the alpha
        interpretation (re-estimated per file) and the embedded colour
        profile record. Verified against AE 2026 for `replace()`,
        `replace_with_sequence()` and `replace_with_placeholder()` over
        movie, sequence, still and placeholder sources. Replacing with a
        solid carries nothing - AE builds that source from the call's
        arguments.
        """
        old_sspc, new_sspc = self._sspc, new._sspc
        new_sspc.field_separation_type = old_sspc.field_separation_type
        new_sspc.high_quality_field_separation = old_sspc.high_quality_field_separation
        new_sspc.remove_pulldown = old_sspc.remove_pulldown
        new_sspc.loop = old_sspc.loop
        new_sspc.pixel_aspect = old_sspc.pixel_aspect

        # A sequence of stills has no rate of its own, so AE keeps its
        # "assume this frame rate" as the native rate and leaves the conform
        # slot at 0; a placeholder keeps its rate the same way. That assumed
        # rate is not a conform: it carries to another sequence, but
        # replacing with a movie leaves the movie playing at its own rate. A
        # real conform carries to either. A new sequence takes whatever rate
        # the old source plays at, so an unconformed movie hands on its own
        # rate; a still or an audio file has none (its native slot is 0),
        # and a new placeholder takes its rate from the call's arguments.
        rate = self.conform_frame_rate
        if new._is_sequence:
            rate = rate or self._sspc.native_frame_rate
            if rate and not new._rate_from_media:
                # A sequence's stored duration is its frame count over its
                # rate, so it has to move with the rate; a movie keeps the
                # duration it measured and gets the conform factor applied.
                _retime_sequence(new_sspc, rate)
        elif (
            rate
            and not self._rate_is_assumed
            and not new._rate_is_assumed
            and not new.is_still
        ):
            new_sspc.conform_frame_rate = rate

        self._carry_color_management_to(new)

    def _join_project(self, project: Project) -> None:
        """Attach a newly built source to `project` and fit its colour
        records to it.

        Every path that attaches a new source to a project calls this
        (`FootageItem._new`, a replace, a proxy). A source is built with the
        `LIST:CLRS` records of the latest release (`build_pin_list`); After
        Effects writes the older layout when it saves an older version, so
        the records the project's file version predates are dropped
        (`_CLRS_RECORDS_SINCE`). A file source also records the input colour
        space of an OCIO-managed project (see `FileSource._join_project`).
        """
        self._project = project
        if self._clrs is None:
            return
        head = project._head
        version = (head.file_format_version, head._format_subversion)
        dropped = {marker for marker, since in _CLRS_RECORDS_SINCE if version < since}
        chunks = self._clrs.chunks
        kept = []
        index = 0
        while index < len(chunks):
            if chunks[index].chunk_type in dropped:
                index += 2  # the marker and the Utf8 that follows it
                continue
            kept.append(chunks[index])
            index += 1
        chunks[:] = kept

    def _carry_color_management_to(self, new: FootageSource) -> None:
        """Copy the Color Management choices AE carries over to `new`.

        The assigned profile (`apid` plus the `ocsp` envelope that holds its
        bytes) only carries when one is assigned; when it is not, the new
        source keeps the profile AE derives from the new file. In an OCIO
        project every file has an assigned space - the one the config's file
        rules gave it or one the user picked - and it carries even when the
        new file's rules would pick another (AE 2026). The embedded profile
        record is always the new file's.
        """
        old_clrs, new_clrs = self._clrs, new._clrs
        if old_clrs is None or new_clrs is None:
            return
        for chunk_type in ("ipws", "linl"):
            old_chunk = cast(
                "U1Chunk", find_by_type(chunks=old_clrs.chunks, chunk_type=chunk_type)
            )
            new_chunk = cast(
                "U1Chunk", find_by_type(chunks=new_clrs.chunks, chunk_type=chunk_type)
            )
            new_chunk.value = old_chunk.value
        toggle_flag_chunk(new_clrs, "prgb", self.preserve_rgb)

        old_apid = find_by_type(chunks=old_clrs.chunks, chunk_type="apid")
        if old_apid.data == _UNASSIGNED_PROFILE:
            old_profile = self._ocsp_profile()
            if old_profile is None or not old_profile.is_ocio:
                return
        find_by_type(chunks=new_clrs.chunks, chunk_type="apid").data = old_apid.data
        old_ocsp, new_ocsp = self._ocsp_utf8(), new._ocsp_utf8()
        if old_ocsp is not None and new_ocsp is not None:
            new_ocsp.value = old_ocsp.value

    def _store_name(self, value: str) -> None:
        """Write the item display name into the source's own `opti` chunk.

        The counterpart of `_resolve_name`: it must store the name where that
        method reads it back from, or the rename is lost on save. Only called
        for a source that owns its name (see `_owns_name`).
        """
        raise NotImplementedError

    def _icc_lib(self) -> IccProfileLibrary:
        """ICC library for Adobe-CMS profile writes - the owning project's
        (honouring `icc_profile_dirs`) when wired, else the global default."""
        if self._project is not None:
            return self._project._icc_lib()
        return default_icc_library()

    @property
    def preserve_rgb(self) -> bool:
        """When `True`, the footage Preserve RGB setting is enabled.
        From the Interpret Footage > Color Management tab. Read / Write.

        Note:
            Not exposed in ExtendScript."""
        if self._clrs is None:
            return False
        return any(c.chunk_type == "prgb" for c in self._clrs.chunks)

    @preserve_rgb.setter
    def preserve_rgb(self, value: bool) -> None:
        validate_bool(value)
        if self._clrs is None:
            raise AttributeError(
                "Cannot set preserve_rgb: no CLRS container. Update the value in After Effects then re-parse the project to modify this footage source."
            )
        toggle_flag_chunk(self._clrs, "prgb", value)

    @property
    def media_color_space(self) -> str:
        """The media color space from the Interpret Footage >
        Color Management tab. Read / Write.

        Returns `"Embedded"`, `"Working Color Space"`, the name of an assigned
        OCIO color space, or the name of an Adobe ICC profile (e.g.
        `"Apple RGB"`). As with [working_space][py_aep.models.project.Project.working_space],
        an assigned OCIO space reads back as AE's stored `colorProfileName`:
        `"<family>/<name>"` for a direct color-space pick (e.g.
        `"ACES/ACES - ACEScg"`), or the target name for a role/alias pick.

        Writable: `"Working Color Space"`, `"Embedded"`, an Adobe ICC profile
        name, or - in OCIO mode - any color space, role, alias or
        `display/view` pair of the project's OCIO configuration (the
        `"<family>/<name>"` form this getter returns is accepted too). The
        config must be resolvable, since the envelope AE writes depends on
        which kind the name is. An Adobe profile is identified by its 16-byte
        ID and its ICC bytes are discovered on disk
        (`ColorProfileNotFoundError` if not installed).

        Note:
            Assigning back what this getter returns is lossy for a ROLE pick.
            AE stores the role's TARGET, not the role, and many roles can
            share one target (ACES 1.2 points `rendering`, `scene_linear` and
            `compositing_linear` all at `ACES - ACEScg`), so which role was
            chosen is not recoverable from the file. Re-assigning the target
            name records a direct color-space pick instead - the same color
            transform, different bytes. Pass the role name (e.g.
            `"matte_paint"`) to write a role pick.

        Note:
            Not exposed in ExtendScript."""
        if self._clrs is None:
            return "Embedded"
        ipws_chunk = cast(
            "U1Chunk", find_by_type(chunks=self._clrs.chunks, chunk_type="ipws")
        )
        if ipws_chunk.value:
            return "Working Color Space"
        # In OCIO mode the assigned color space is carried as an OCIO envelope in
        # the `ocsp` Utf8 (apid is the unmanaged sentinel). In Adobe mode `ocsp`
        # holds the embedded/override profile and `apid` is the discriminator.
        ocsp = self._ocsp_profile()
        if ocsp is not None and ocsp.profile_type == PROFILE_TYPE_OCIO:
            return ocsp.name
        apid_chunk = find_by_type(chunks=self._clrs.chunks, chunk_type="apid")
        return map_media_color_space(False, apid_chunk.data)

    @media_color_space.setter
    def media_color_space(self, value: str) -> None:
        validate_string(value)
        if self._clrs is None:
            raise AttributeError(
                "Cannot set media_color_space: no CLRS container. Update the "
                "value in After Effects then re-parse the project to modify "
                "this footage source."
            )
        ipws_chunk = cast(
            "U1Chunk", find_by_type(chunks=self._clrs.chunks, chunk_type="ipws")
        )
        apid_chunk = find_by_type(chunks=self._clrs.chunks, chunk_type="apid")
        if value == "Working Color Space":
            # AE sets ipws, clears the override id, and empties the ocsp Utf8.
            ipws_chunk.value = 1
            apid_chunk.data = b"\xff" * 16
            self._write_ocsp("")
            return
        ipws_chunk.value = 0
        if value == "Embedded":
            # Revert to the file's embedded profile (mirrored in the Mcsp Utf8).
            apid_chunk.data = b"\xff" * 16
            self._write_ocsp(self._embedded_envelope())
            return
        if profile_id_for_name(value) is not None:
            # Adobe ICC override: apid is the catalogued profile ID and the ocsp
            # carries the embedded ICC bytes (discovered from the standard Adobe
            # Color dirs). For most profiles the bytes hash to the same ID; the
            # handful AE generates a private variant for (Apple/Adobe RGB,
            # ColorMatch, ROMM) embed the on-disk copy AE still recognizes.
            lib = self._icc_lib()
            apid_chunk.data = lib.hash_for(value)
            self._write_ocsp(build_icc_envelope(value, lib.bytes_for(value)))
            return
        # Treat any other name as an OCIO color space (no ICC, apid unmanaged).
        # The envelope depends on the SELECTION KIND, so the config is
        # required - AE-verified against a direct-pick and a role-pick sample.
        apid_chunk.data = b"\xff" * 16
        self._write_ocsp(self._ocio_envelope(value))

    def _ocio_envelope(self, name: str) -> str:
        """Build the OCIO envelope AE writes for `name` (see
        [ocio_color_profile_envelope][py_aep.color.ocio.ocio_color_profile_envelope])."""
        project = self._project
        config = require_ocio_config(
            project.ocio_configuration_file if project is not None else None,
            f"build the color-profile envelope for {name!r}",
        )
        return ocio_color_profile_envelope(config, name)

    def _ocsp_utf8(self) -> Utf8Chunk | None:
        """The `Utf8` chunk after the CLRS `ocsp` marker (the assigned space)."""
        if self._clrs is None:
            return None
        try:
            after = find_chunks_after(
                chunks=self._clrs.chunks, chunk_type="Utf8", after_type="ocsp"
            )
        except ChunkNotFoundError:
            return None
        return cast("Utf8Chunk", after[0]) if after else None

    def _ocsp_profile(self) -> ColorProfile | None:
        utf8 = self._ocsp_utf8()
        if utf8 is None or "baseColorProfile" not in utf8.value:
            return None
        return parse_envelope(utf8.value)

    def _embedded_envelope(self) -> str:
        """The embedded source profile envelope (CLRS `Mcsp` Utf8), or `{}`."""
        if self._clrs is None:
            return "{}"
        try:
            after = find_chunks_after(
                chunks=self._clrs.chunks, chunk_type="Utf8", after_type="Mcsp"
            )
        except ChunkNotFoundError:
            return "{}"
        return cast("Utf8Chunk", after[0]).value if after else "{}"

    def _write_ocsp(self, envelope: str) -> None:
        utf8 = self._ocsp_utf8()
        if utf8 is None:
            raise AttributeError(
                "Cannot set media_color_space: no 'ocsp' color chunk in CLRS."
            )
        utf8.value = envelope

    @property
    def is_still(self) -> bool:
        """When `True` the footage is still; When `False`, it has a
        time-based component. Read-only."""
        return self._sspc.duration == 0
